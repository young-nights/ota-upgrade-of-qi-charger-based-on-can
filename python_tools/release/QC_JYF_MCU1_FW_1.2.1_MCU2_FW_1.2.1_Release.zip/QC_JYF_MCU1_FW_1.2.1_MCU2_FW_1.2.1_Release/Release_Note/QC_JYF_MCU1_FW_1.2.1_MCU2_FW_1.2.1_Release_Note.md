# JYF Qi Charger Firmware Release Note

## 版本信息

| 项目 | 值 |
|------|-----|
| MCU1 版本 | QC_JYF_MCU1_FW_1.2.1 |
| MCU2 版本 | QC_JYF_MCU2_FW_1.2.1 |
| 硬件版本 | QC_JYF_HW_1.1.5 |
| 发布日期 | 2026-10-16 |
| 发布类型 | 正式发布 |

## 发布文件

| 文件 | 用途 | MD5 |
|------|------|-----|
| QC_JYF_MCU1_FW_1.2.1_fde04859510297df62fddfae91de91c3.img | MCU1 OTA | fde04859510297df62fddfae91de91c3 |
| QC_JYF_MCU1_FW_1.2.1_d87704e1c4649069d0cbbfe355c7e70d.bin | MCU1 烧录 | d87704e1c4649069d0cbbfe355c7e70d |
| QC_JYF_MCU2_FW_1.2.1_26008d5764676d856a3ffb80ca797317.img | MCU2 OTA | 26008d5764676d856a3ffb80ca797317 |
| QC_JYF_MCU2_FW_1.2.1_e85a4a3f1c6c666744cf98f8ea67325d.bin | MCU2 烧录 | e85a4a3f1c6c666744cf98f8ea67325d |

## Change Log

### MCU1 (1.2.1)
1. 低功耗 Sleep 模式重构（移除 Standby，修复 anti-phantom）
2. 充电期间禁止进入 Sleep
3. Qi 版本号改为三字节 major.minor.patch
4. 生命周期帧 1s 周期广播
5. CAN 诊断帧（0x18FF270D）

### MCU2 (1.2.1)
- 配套 MCU1 v1.2.1 验证

## 已知问题

| Hall 传感器噪声可能误判设备在位 | 强磁场干扰 | 充电门禁误触发 | 无 |

## 烧录说明

- MCU1: J-Link/AT32 ISP 从 0x08000000 烧录 .bin
- MCU2: 对应烧录器烧录 .bin
- OTA: MCU1 用 .img 通过 CAN UDS；MCU2 用 .img 通过 Qi IAP
