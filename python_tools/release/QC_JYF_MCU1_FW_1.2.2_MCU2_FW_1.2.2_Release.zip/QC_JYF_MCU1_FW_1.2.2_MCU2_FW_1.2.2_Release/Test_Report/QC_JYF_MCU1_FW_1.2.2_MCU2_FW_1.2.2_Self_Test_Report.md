# JYF Qi Charger Firmware Self Test Report

| 项目 | 值 |
|------|-----|
| MCU1 版本 | QC_JYF_MCU1_FW_1.2.2 |
| MCU2 版本 | QC_JYF_MCU2_FW_1.2.2 |
| 硬件版本 | QC_JYF_HW_1.1.5 |
| 测试日期 | 2026-10-16 |
| 测试工程师 | xuanxuan |

## 测试文件

| QC_JYF_MCU1_FW_1.2.2_f05893022acb9793961b58bccea69ddd.img | MCU1 OTA | f05893022acb9793961b58bccea69ddd |
| QC_JYF_MCU1_FW_1.2.2_b4e8d86e23391ef21ce13b397aeacefd.bin | MCU1 烧录 | b4e8d86e23391ef21ce13b397aeacefd |
| QC_JYF_MCU2_FW_1.2.2_cc8c6a6ea31fa2c1d0255ed0c08fa842.img | MCU2 OTA | cc8c6a6ea31fa2c1d0255ed0c08fa842 |
| QC_JYF_MCU2_FW_1.2.2_e85a4a3f1c6c666744cf98f8ea67325d.bin | MCU2 烧录 | e85a4a3f1c6c666744cf98f8ea67325d |

## 基础功能回归

| 测试项 | 结果 |
|--------|------|
| 上电初始化 | PASS |
| 正常充电启停 | PASS |
| Qi 设备检测 | PASS |
| 双 MCU 版本上报 | PASS |
| 复位/断电重启 | PASS |
