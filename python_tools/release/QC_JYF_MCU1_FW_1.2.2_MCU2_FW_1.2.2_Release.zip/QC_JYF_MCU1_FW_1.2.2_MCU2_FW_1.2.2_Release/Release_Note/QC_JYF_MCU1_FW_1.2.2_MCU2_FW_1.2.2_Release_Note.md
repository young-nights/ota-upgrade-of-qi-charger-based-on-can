# JYF Qi Charger Firmware Release Note

## 版本信息

| 项目 | 值 |
|------|-----|
| MCU1 版本 | QC_JYF_MCU1_FW_1.2.2 |
| MCU2 版本 | QC_JYF_MCU2_FW_1.2.2 |
| 硬件版本 | QC_JYF_HW_1.1.5 |
| 发布日期 | 2026-10-16 |
| 发布类型 | 正式发布 |

## 发布文件

| 文件 | 用途 | MD5 |
|------|------|-----|
| QC_JYF_MCU1_FW_1.2.2_f05893022acb9793961b58bccea69ddd.img | MCU1 OTA | f05893022acb9793961b58bccea69ddd |
| QC_JYF_MCU1_FW_1.2.2_b4e8d86e23391ef21ce13b397aeacefd.bin | MCU1 烧录 | b4e8d86e23391ef21ce13b397aeacefd |
| QC_JYF_MCU2_FW_1.2.2_cc8c6a6ea31fa2c1d0255ed0c08fa842.img | MCU2 OTA | cc8c6a6ea31fa2c1d0255ed0c08fa842 |
| QC_JYF_MCU2_FW_1.2.2_e85a4a3f1c6c666744cf98f8ea67325d.bin | MCU2 烧录 | e85a4a3f1c6c666744cf98f8ea67325d |

## Change Log

### MCU1 (1.2.2)
- 在 1.2.1 基础上构建

### MCU2 (1.2.2)
- Qi IAP 固件更新

## 已知问题

| Hall 传感器噪声可能误判设备在位 | 强磁场干扰 | 充电门禁误触发 | 无 |

## 烧录说明

- MCU1: J-Link/AT32 ISP 从 0x08000000 烧录 .bin
- MCU2: 对应烧录器烧录 .bin
- OTA: MCU1 用 .img 通过 CAN UDS；MCU2 用 .img 通过 Qi IAP
